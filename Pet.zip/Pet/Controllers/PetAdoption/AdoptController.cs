﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PetCare.BLL;

namespace PetCare.Controllers.PetAdoption
{
    public class AdoptController : Controller
    {
        //
        // GET: /Adopt/

        public JsonResult GetBasicMessage()
        {
            KnowledgePet know = new KnowledgePet();
            know.GetKnowledgePetList();
            return Json("This is a message from AdoptController",JsonRequestBehavior.AllowGet);
        }

    }
}
